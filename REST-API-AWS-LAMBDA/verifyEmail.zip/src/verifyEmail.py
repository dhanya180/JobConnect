import json
import boto3
import botocore
import random
import logging
from pprint import pprint

# Get the service resource.
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Users')


client = boto3.client('ses', region_name='ap-south-1')

def lambda_handler(event, context):
    
    Access_Code =""
    try:
        response = table.get_item( Key={"Login_Id": event["Login_Id"]} )
    except Exception as err:
        return { "statusCode": 202, "body": json.dumps({"Login_Id": event["Login_Id"], "Status": "Login Id does not exists"})}
    if 'Item' in response:

        if event["Action"] == "SendAccessCode": 
    
                item = response["Item"]
                if len(item["Email"]) < 13:
                     return { "statusCode": 202, "body": json.dumps({"Email": item["Email"], "Status": "Not a valid Email-ID"}) }
                Access_Code = str(random.randrange(123456, 987654))
                table.update_item( Key={"Login_Id": event["Login_Id"]},
                                    UpdateExpression='SET Access_Code = :val1, Email_Status = :val2',
                                    ExpressionAttributeValues={':val1': Access_Code, ':val2':"UNVERIFIED"}
                                  )
                try:
                        response = client.send_email(
                                                        Destination={ 'ToAddresses': [item["Email"]] },
                                                        Message={
                                                                    'Body': {
                                                                        'Text': {
                                                                            'Charset': 'UTF-8',
                                                                            'Data': 'Hi '+ item['User_Name'] + ', \n' + 'Access Code for your Email verificatioin is : ' + Access_Code,
                                                                                }
                                                                            },
                                                                    'Subject': {
                                                                                'Charset': 'UTF-8',
                                                                                'Data': 'Access Code for JobConnect verification',
                                                                                },
                                                                },
                                                        Source="JobConnects@protonmail.com"
                                                    )
                except Exception as e:
                        raise
                        return {
                                  "statusCode": 200,
                                  "body": json.dumps({"Status": "Unable to verify Email. Please update your email id in the application"})
                               }
                else:
                        return {
                                'statusCode': 200,
                                'body': json.dumps({"Status": "Email Sent"})
                               }
        elif event["Action"] == "VerifyEmail": 
                item = response['Item']
                try:
                    if item["Access_Code"] == event["Access_Code"]:
                        table.update_item(
                                           Key={ "Login_Id": event["Login_Id"] },
                                           UpdateExpression='SET Email_Status = :val1',
                                           ExpressionAttributeValues={ ':val1': "VERIFIED" }
                                         )
                        return {
                                  "statusCode": 200,
                                  "body": json.dumps({"Email": item["Email"], "Status": "Email Verified"})
                               }
                    else:
                        return {
                                  "statusCode": 202,
                                  "body": json.dumps({"Email": item["Email"], "Status": "Access Code mismatch. Email is not yet verified"})
                               }
                except Exception as err:
                       raise
                       return {
                                  "statusCode": 200,
                                  "body": json.dumps({"Login_Id": event["Login_Id"], "Status": "Email already Verified"})
                               }
        else:
            return {
                      "statusCode": 202,
                      "body": json.dumps({"Status": "Invalid Action Code sent. Please check API documentation"})
                   }     
    else:
        return { "statusCode": 202, "body": json.dumps({"Login_Id": event["Login_Id"], "Status": "Login Id does not exists"})}