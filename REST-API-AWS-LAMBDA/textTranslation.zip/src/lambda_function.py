import json
import boto3

client = boto3.client('translate')

def lambda_handler(event, context):
    # TODO implement
    response = client.translate_text(
            Text='string',
            SourceLanguageCode='en',
            TargetLanguageCode='ta',
            Settings={
                'Formality': 'FORMAL',
                'Brevity': 'ON'
            }
           )
    return {
        'statusCode': 200,
        'body': "responseite"
    }
