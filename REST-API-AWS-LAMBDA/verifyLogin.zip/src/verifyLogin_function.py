import json
import boto3

# Get the service resource.
dynamodb = boto3.resource('dynamodb', 'ap-south-1')
dynamodb_table = dynamodb.Table('Users')

def lambda_handler(event, context):
    try:
       response = dynamodb_table.get_item(
                              Key={"Login_Id": event["Login_Id"]},
                              ProjectionExpression="Email, Email_Status, Mobile_Number, User_Name, Password"
                             )
    except Exception as e:
        raise
        return {
              "statusCode": 200,
              "body": json.dumps({"Login_Id": event["Login_Id"], "Status": "User not found"})
               }
    else:
        if 'Item' in response:
            item = response['Item']
            if (event['Password'] == item["Password"]):
              loginStatus = "Success"
              if item["Email_Status"] != "Verified":
                 loginStatus = "Email not yet verified" 
            else:
              loginStatus = "Failure"
              return {
                    "statusCode": 210,
                    "body": json.dumps({"Login_Id": event["Login_Id"], "Status": loginStatus})
                    }
        else:
            return {
              "statusCode": 200,
              "body": json.dumps({"Login_Id": event["Login_Id"], "Status": "User not found"})
            }
    
    return {
    "statusCode": 200,
    "body": json.dumps({"Login_Id": event["Login_Id"], "Status": loginStatus, "User_Name":item["User_Name"], "Mobile_Number":item["Mobile_Number"],"Email": item["Email"] })
    }
