import json
import boto3

from boto3.dynamodb.conditions import Key, Attr

# Get the service resource.
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Job_Types')

def lambda_handler(event, context):
    # TODO implement
    try:
            response = table.scan()
            items = response['Items']
    except Exception as e:
        raise
    return {
        "statusCode": 200,
        "Status": "Success",
        "body": json.dumps(items)
        }