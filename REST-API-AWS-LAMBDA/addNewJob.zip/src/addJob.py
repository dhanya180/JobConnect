import json
import boto3

# Get the service resource.
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Jobs')

def lambda_handler(event, context):
    try:
        table.put_item(
            Item={
                                "Login_Id":event["Login_Id"],
                                "Job_Id":event["Job_Id"],
                                "Job_Type":event["Job_Type"].upper(),
                                "Job_Openings":event["Job_Openings"],
                                "Date_From":event["Date_From"],
                                "Date_To":event["Date_To"],
                                "Job_Description":event["Job_Description"],
                                "Job_Status":event["Job_Status"].upper(),
                                "Job_City":event["Job_City"].upper(),
                                "Job_Pincode":event["Job_Pincode"],
                                "Job_State":event["Job_State"].upper(),
                                "Job_Street":event["Job_Street"],
                                "Lattitude":event["Lattitude"],
                                "Longtitude":event["Longtitude"],
                                "Payment_Frequency":event["Payment_Frequency"],
                                "Wage_Minimum":event["Wage_Minimum"],
                                "Wage_Maximum":event["Wage_Maximum"],
                                "Name_JP": event["Name_JP"],
                                "Mobile_Number_JP":event["Mobile_Number_JP"],
                                "Email_JP": event["Email_JP"],
                                "Login_Id_JS": "",
                                "Mobile_Number_JS": "",
                                "Email_JS": "",
                                "Name_JS": "",
                                "Requested_Wage":event["Wage_Maximum"]
                            }
                      )
                      
    except Exception as e:
        raise
        return {
              "statusCode": 210,
              "body": json.dumps({"Login_Id": event["Login_Id"], "Job_Id":event["Job_Id"], "Status": "Job not added"})
               }
    table2 = dynamodb.Table('Job_Types')
    table2.put_item( Item={ "Job_Type":event["Job_Type"].upper()})
    return {
        'statusCode': 200,
        'body': json.dumps({"Login_Id": event["Login_Id"], "Job_Id":event["Job_Id"], "Status": "Job added"})
    }
    